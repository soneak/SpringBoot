package com.cg.demo;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/hello-world-service/Hello")
public class Controller {

	
	private static final String template = "Helloworld!";
    private final  AtomicLong counter = new AtomicLong();

    @RequestMapping(method = RequestMethod.GET)
    
    public Model demo() {
    	
        return new Model(counter.incrementAndGet(),template);
    }
    
}

