package com.example.demo;

import static org.junit.Assert.*;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import static org.junit.Assert.assertTrue;

import com.cg.demo.Controller;
import com.cg.demo.Model;

import junit.framework.Assert;

@SpringBootConfiguration
@RunWith(SpringRunner.class)
@SpringBootTest
public class DemoApplicationTests {

	Controller controller = new Controller();

	@Test
	public void contextLoads() {
		long id = 1;
		String description = "Helloworld!";
		Model mod = new Model(id, description);

		assertTrue(EqualsBuilder.reflectionEquals(mod, controller.demo()));
		// assertTrue(mod.equals(Controller.demo()));
		// Assert.assertEquals(mod,controller.demo());
	}
}
