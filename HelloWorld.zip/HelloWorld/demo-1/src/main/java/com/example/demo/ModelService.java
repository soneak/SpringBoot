package com.example.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class ModelService {

	private List<Model> obj = new ArrayList<>(Arrays.asList(new Model(1, "HelloWorld")));

	public List<Model> getAllModel() {
		// TODO Auto-generated method stub
		return obj;
	}

	public void addmodel(Model model) {
		// TODO Auto-generated method stub
		obj.add(model);

	}

}
