package com.example.demo;

public class Model {
	private long id;

	private String description;

	public Model() {

	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Model [id=" + id + ", description=" + description + "]";
	}

	public Model(long id, String description) {
		super();
		this.id = id;
		this.description = description;
	}

}
