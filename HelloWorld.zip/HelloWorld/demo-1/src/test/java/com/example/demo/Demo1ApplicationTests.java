package com.example.demo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import junit.framework.Assert;

import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest
public class Demo1ApplicationTests {

	Controller controller = new Controller();

	@Test
	public void contextLoads() {
		/*
		 * long id = 1; String description="Helloworld!"; Model mod= new
		 * Model(id,description);
		 */
		// assertTrue(EqualsBuilder.reflectionEquals(mod,controller.demo()));

		// Assert.assertEquals(mod,controller.getAllModel());

		List<Model> list = new ArrayList<Model>();
		Model b1 = new Model(0,"HelloWorld");
    
		// Hello mod= new Hello(id,message);

		// Assert.assertTrue(EqualsBuilder.reflectionEquals(mod,controller.getAllName()));
		assertTrue(b1.equals(controller.getAllModel()));
		// List<String> categories = asList("one", "two", "three");
	}

}
